package com.hiraganaarena.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int lang = textToSpeech.setLanguage(Locale.JAPAN);
                // TTS siap meskipun paket bahasa Jepang belum tersedia; speak() akan mencoba Indonesia.
                ttsReady = lang != TextToSpeech.ERROR;
            }
        });
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        webView.addJavascriptInterface(new TtsBridge(), "AndroidTTS");
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    private class TtsBridge {
        @JavascriptInterface
        public boolean speak(String text, String language) {
            if (textToSpeech == null || !ttsReady || text == null) return false;
            Locale locale = "ja-JP".equalsIgnoreCase(language) ? Locale.JAPAN : new Locale("id", "ID");
            int result = textToSpeech.setLanguage(locale);
            String spokenText = text;
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.ERROR) {
                if (!"ja-JP".equalsIgnoreCase(language)) return false;
                result = textToSpeech.setLanguage(new Locale("id", "ID"));
                // Fallback baca romaji, bukan karakter Jepang yang mungkin tidak didukung.
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.ERROR) return false;
                spokenText = text;
            }
            textToSpeech.setSpeechRate(0.82f);
            textToSpeech.speak(spokenText, TextToSpeech.QUEUE_FLUSH, null, "kana-" + System.currentTimeMillis());
            return true;
        }
    }
    @Override protected void onDestroy() {
        if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); }
        if (webView != null) { webView.removeJavascriptInterface("AndroidTTS"); webView.destroy(); }
        super.onDestroy();
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
